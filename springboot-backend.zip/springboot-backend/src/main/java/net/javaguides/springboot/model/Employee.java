package net.javaguides.springboot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="employees")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	
	private long id;
	@Column(name="Ad")
	private String Ad;
	@Column(name="Soyad")
	private String Soyad;
	@Column(name="Etkinlik")
	private String Etkinlik;
	
	
	public Employee() {
		
	}
	
	public Employee(String Ad,String Soyad,String Etkinlik) {
		super();
		this.Ad=Ad;
		this.Soyad=Soyad;
		this.Etkinlik=Etkinlik;
		
	
	}
	
	public long getId() {
		return id;
	}
	
	
	public String getAd() {
		return Ad;
		
	}
	
	public String getSoyad() {
		return Soyad;
	}
	
	public String getEtkinlik() {
		return Etkinlik;
	}


	public void setId(long id) {
		this.id = id;
	}


	public void setAd(String ad) {
		Ad = ad;
	}


	public void setSoyad(String soyad) {
		Soyad = soyad;
	}


	public void setEtkinlik(String etkinlik) {
		Etkinlik = etkinlik;
	}

}
