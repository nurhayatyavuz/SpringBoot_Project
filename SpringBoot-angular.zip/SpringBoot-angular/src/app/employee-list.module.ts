import { NgModule } from '@angular/core';
import { EmployeeListComponent } from './employee-list/employee-list.component';

@NgModule({
  declarations: [EmployeeListComponent],
  exports: [EmployeeListComponent]
})
export class AppEmployeeListModule {}