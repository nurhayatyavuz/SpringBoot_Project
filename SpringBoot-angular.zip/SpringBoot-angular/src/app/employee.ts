export class Employee {
    id:number | undefined;
    Ad:string| undefined;
    Soyad:string| undefined;
    Etkinlik:string| undefined;
}
